package com.ray.fragment.view

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.ray.fragment.R

class TestActivity:AppCompatActivity(){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activty_test)
    }
}