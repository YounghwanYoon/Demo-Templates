package com.ray.srt_smi_converter.view.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.ray.srt_smi_converter.R

class CustomedAdapter(val context: Context?, val singleLayout:Int, var list: MutableList<String>) : RecyclerView.Adapter<CustomedAdapter.MyViewHolder>(){

    private var TAG:String = this.javaClass.simpleName.toString()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        var eachView = LayoutInflater.from(context).inflate(singleLayout, parent, false) as View
        val myViewHolder = MyViewHolder(eachView)

        return myViewHolder
    }

    override fun getItemCount(): Int {
        return list.size
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        holder.eachView(list[position])
    }

    class MyViewHolder(private var eachView:View): RecyclerView.ViewHolder(eachView){

        fun eachView(dir: String){
            val image = eachView.findViewById<ImageView>(R.id.imageView)
            val directory = eachView.findViewById<TextView>(R.id.resource_dir_textview)

            //Set directory
            directory.text = dir
            image.setImageResource(chooseImage(dir))
        }

        fun chooseImage(directory:String): Int{
            val dirType = checkTypeOfFile(directory)
            var imageChoice:Int = 0

            //Choose Image based on directory type.
            when(dirType){
                "mp3" -> imageChoice = R.drawable.ic_music//return Image
                "mp4" -> imageChoice = R.drawable.ic_video
                "avi" -> imageChoice = R.drawable.ic_video
                "smi" -> imageChoice = R.drawable.ic_file
                "srt" -> imageChoice = R.drawable.ic_file
            }

            return imageChoice
        }

        fun checkTypeOfFile(directory:String):String{
            var fileType:String
            if(directory.endsWith(".mp3")) {fileType = "mp3"}
            else if(directory.endsWith(".mp4")){fileType = "avi"}
            else if(directory.endsWith(".avi")){fileType = "mp4"}
            else if(directory.endsWith(".smi")){fileType = "smi"}
            else if(directory.endsWith(".srt")){fileType = "srt"}
            else{
                fileType="unknown"
            }
            return fileType
        }
    }
}