# Template/Demo for future references

Language used: 
- Kotlin

Contains followings: 

-MVVM 
-REST API
-SQLITE
-LISTVIEW/Recycler View
-GOOGLE-LOGIN-API
-Fragments

